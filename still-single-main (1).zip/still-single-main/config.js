const CONFIG = {
    titleWeb: "Love confess",
    introTitle: 'Who are you',
    introDesc: `Trái đất vốn lạ thường
    Mà sao em cứ đi nhầm đường
    Lạc vào tim anh lẻ loi
    Đằng sau chữ yêu đây là thương`,
    btnIntro: '^^HiHi^^',
    title: 'Làm người yêu tớ nha 🥰',
    desc: '',
    btnYes: 'Thích lắm <33',
    btnNo: 'Không nha :3',
    question: 'Cho tớ biết lí do đi',
    btnReply: 'Gửi cho bạn <3',
    reply: 'Yêu thì yêu mà không yêu thì yêu',
    mess: 'Mình biết mà 🥰. Yêu bạn nhiều nhiều 😘😘',
    messDesc: 'Tối nay 7h, mình qua đón đi chơi nha.',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://www.facebook.com/groups/tek4.vn/'
}
