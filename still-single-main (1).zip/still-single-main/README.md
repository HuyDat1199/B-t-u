Để chỉnh sửa trong web theo ý của bạn, bản cần chỉnh sửa file config.js </br>

Bạn có thể chỉnh sửa tên website, tên crush của bạn, chỉnh sửa đương link thành link message của bạn, ... </br>